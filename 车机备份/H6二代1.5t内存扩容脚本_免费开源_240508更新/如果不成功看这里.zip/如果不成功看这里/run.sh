#!/bin/sh
#脚本内容不能随便修改，修改后无法运行--
#开启免U盘请加微信W8362832
sh /map/laotou/laotou.sh
