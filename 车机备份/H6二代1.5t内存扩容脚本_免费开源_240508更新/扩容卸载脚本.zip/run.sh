#!/bin/sh
#哈小弗哈弗H6二代车机优化脚本！aaaaaaa
path=`dirname $0`
log="/mnt/udisk/log.log"
laotou_sh="/map/laotou/laotou.sh"
laotou_d="/map/jlaotou"
mount -o remount,rw /system
mount -o remount,rw /mnt/udisk
ls /map/laotou >> $log
echo "以上是目录结构===================。" >> $log

#检查其他版本的扩容数据是否存在
if test -f ${laotou_sh} ;then
    echo "检测到存在其他版本的扩容脚本，正在清除。" >> $log
	echo "检测到存在其他版本的扩容脚本，正在清除。"
	rm -r $laotou_sh
	if [ $? -eq 0 ]; then
		echo "清理完成！等待重启后请重新开始！" >> $log
		echo "清理完成！等待重启后请重新开始！"
		sync
		sleep 2
		reboot
		exit 1
	else
		echo "清除失败，脚本停止运行" >> $log
		echo "清除失败，脚本停止运行"
		exit 1
	fi
	
else
    if test -d ${laotou_d} ;then
		echo "检测到存在旧版本的扩容脚本残留，正在恢复。" >> $log
		echo "检测到存在旧版本的扩容脚本残留，正在恢复。"
		rm -rf $laotou_d
		if [ $? -eq 0 ]; then
			echo "残留数据清理成功" >> $log
			echo "残留数据清理成功"
		else
			echo "残留数据清理失败，脚本停止运行" >> $log
			echo "残留数据清理失败，脚本停止运行"
			exit 1
		fi
	else
		echo "没有发现旧版残留，脚本继续。" >> $log
		echo "没有发现旧版残留，脚本继续。"
	fi
fi
echo "所有操作已结束，车机准备重启" >> $log
echo "所有操作已结束，车机准备重启"
sync
sleep 2
rm -rf $0
reboot
