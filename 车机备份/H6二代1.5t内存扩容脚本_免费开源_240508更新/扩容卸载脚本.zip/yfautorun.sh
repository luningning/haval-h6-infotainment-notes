#!/bin/sh
#H6二代1.5T车机19G扩容脚本，远程1V1服务请加下面下面微信。
#By:哈小弗   WX：W8362832
sh /mnt/udisk/run.sh