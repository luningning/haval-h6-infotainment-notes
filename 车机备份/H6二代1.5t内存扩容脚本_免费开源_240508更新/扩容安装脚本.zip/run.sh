#!/bin/sh
#哈小弗哈弗H6二代车机优化脚本！
sys_app="/data/app"
sys_data="/data/data"
sys_media="/data/media"
bin="/mnt/udisk/dll/bin.bin"
bin_sys="/system/bin/yfbtconfiginit.sh"
bin2_sys="/system/bin/init.j6headunitboard.cpuset.sh"
laotou="/mnt/udisk/dll/laotou.bin"
bak="/mnt/udisk/dll/bak.bin"
bak2="/mnt/udisk/dll/bak2.bin"
log="/mnt/udisk/log.log"
laotou_sh="/map/laotou/laotou.sh"
laotou_d="/map/laotou"
tank_root="/map/tank/connect_map"
tank_d="/map/tank"
mount -o remount,rw /system
mount -o remount,rw /mnt/udisk
echo "$(date '+%Y-%m-%d %H:%M:%S') - ========脚本开始========。" >> $log
am start com.baidu.naviauto/.NaviAutoActivity
ls "/map" >> $log
ls "/system/bin/*.sh" >> $log
echo "===================以上是目录结构===================。" >> $log
if test -f ${laotou_sh} ;then
	echo "$(date '+%Y-%m-%d %H:%M:%S') - laotou_sh存在，终止执行。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - laotou_sh存在，终止执行。"
	am start com.android.settings/.Settings
	exit 1
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - laotou_sh不存在，脚本继续。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - laotou_sh不存在，脚本继续。" 
fi

#检查必要文件是否存在
if test -f ${laotou} ;then
	echo "$(date '+%Y-%m-%d %H:%M:%S') - laotou.bin存在，脚本继续。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - laotou.bin存在，脚本继续。"
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - laotou.bin不存在，退出脚本。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - laotou.bin不存在，退出脚本。" 
	am start com.android.settings/.Settings
    exit 1
fi
if test -f ${bin} ;then
	echo "$(date '+%Y-%m-%d %H:%M:%S') - bin.bin存在，脚本继续。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - bin.bin存在，脚本继续。" 
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - bin.bin文件不存在，退出脚本。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - bin.bin文件不存在，退出脚本。" 
	am start com.android.settings/.Settings
    exit 1
fi

if test -f ${bak} ;then
	echo "$(date '+%Y-%m-%d %H:%M:%S') - bak.bin存在，脚本继续。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - bak.bin存在，脚本继续。" 
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - bak.bin文件不存在，退出脚本。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - bak.bin文件不存在，退出脚本。"
	am start com.android.settings/.Settings
    exit 1
fi
if test -f ${bak2} ;then
	echo "$(date '+%Y-%m-%d %H:%M:%S') - bak2.bin存在，脚本继续。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - bak2.bin存在，脚本继续。" 
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - bak2.bin文件不存在，退出脚本。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - bak2.bin文件不存在，退出脚本。"
	am start com.android.settings/.Settings
    exit 1
fi
#检查其他版本的扩容数据是否存在
if test -f ${tank_root} ;then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - 检测到存在其他版本的扩容脚本，正在清除。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - 检测到存在其他版本的扩容脚本，正在清除。"
	rm -r $tank_root >> $log
	if [ $? -eq 0 ]; then
	    cp -af $bak $bin_sys >> $log
		cp -af $bak2 $bin2_sys >> $log
		echo "$(date '+%Y-%m-%d %H:%M:%S') - 清理完成！等待重启后请重新开始！" >> $log
		echo "$(date '+%Y-%m-%d %H:%M:%S') - 清理完成！等待重启后请重新开始！"
		sync
		sleep 2
		reboot
		exit 1
	else
		echo "$(date '+%Y-%m-%d %H:%M:%S') - 清除失败，脚本停止运行" >> $log
		echo "$(date '+%Y-%m-%d %H:%M:%S') - 清除失败，脚本停止运行"
		am start com.android.settings/.Settings
		exit 1
	fi
	
else
    if test -d ${tank_d} ;then
		echo "$(date '+%Y-%m-%d %H:%M:%S') - 检测到存在其他版本的扩容脚本残留，正在恢复。" >> $log
		echo "$(date '+%Y-%m-%d %H:%M:%S') - 检测到存在其他版本的扩容脚本残留，正在恢复。"
		rm -rf $tank_d >> $log
		if [ $? -eq 0 ]; then
			echo "$(date '+%Y-%m-%d %H:%M:%S') - 残留数据清理成功" >> $log
			echo "$(date '+%Y-%m-%d %H:%M:%S') - 残留数据清理成功"
		else
			echo "$(date '+%Y-%m-%d %H:%M:%S') - 残留数据清理失败，脚本停止运行" >> $log
			echo "$(date '+%Y-%m-%d %H:%M:%S') - 残留数据清理失败，脚本停止运行"
			am start com.android.settings/.Settings
			exit 1
		fi
	else
		echo "$(date '+%Y-%m-%d %H:%M:%S') - 没有发现tank残留，脚本继续。" >> $log
		echo "$(date '+%Y-%m-%d %H:%M:%S') - 没有发现tank残留，脚本继续。"
	fi
fi

if test -d ${laotou_d} ;then
	echo "$(date '+%Y-%m-%d %H:%M:%S') - 检测到存在旧版本的扩容脚本残留，正在恢复。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - 检测到存在旧版本的扩容脚本残留，正在恢复。"
	rm -rf $laotou_d >> $log
	if [ $? -eq 0 ]; then
		echo "$(date '+%Y-%m-%d %H:%M:%S') - 旧版残留数据清理成功" >> $log
		echo "$(date '+%Y-%m-%d %H:%M:%S') - 旧版残留数据清理成功"
	else
		echo "$(date '+%Y-%m-%d %H:%M:%S') - 残留数据清理失败，脚本停止运行" >> $log
		echo "$(date '+%Y-%m-%d %H:%M:%S') - 残留数据清理失败，脚本停止运行"
		am start com.android.settings/.Settings
		exit 1
	fi
else
	echo "$(date '+%Y-%m-%d %H:%M:%S') - 没有发现旧版残留，脚本继续。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - 没有发现旧版残留，脚本继续。"
fi
	
echo "$(date '+%Y-%m-%d %H:%M:%S') - 开始删除原车百度地图数据！" >> $log
echo "$(date '+%Y-%m-%d %H:%M:%S') - 开始删除原车百度地图数据！"
rm -rf /map/BaiduMapAuto/* >> $log
if [ $? -eq 0 ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - 百度地图数据清理完成。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - 百度地图数据清理完成。"
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - 百度地图数据清理失败，后续可以尝试手动清理。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - 百度地图数据清理失败，后续可以尝试手动清理。"
fi

mkdir -p $laotou_d >> $log
if [ $? -eq 0 ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - 扩展数据目录创建成功。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - 扩展数据目录创建成功。"
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - 扩展数据目录创建失败，停止脚本。" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - 扩展数据目录创建失败，停止脚本。" 
	am start com.android.settings/.Settings
    exit 1
fi
sleep 1

echo "=================================================="
echo "$(date '+%Y-%m-%d %H:%M:%S') - 开始迁移数据目录" >> $log
echo "$(date '+%Y-%m-%d %H:%M:%S') - 开始迁移数据目录" 
cp -a $sys_app $laotou_d >> $log
if [ $? -eq 0 ]; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') - APP目录转移成功,开始转移MEDIA目录" >> $log
  echo "$(date '+%Y-%m-%d %H:%M:%S') - APP目录转移成功,开始转移MEDIA目录"
else
  echo "$(date '+%Y-%m-%d %H:%M:%S') - APP目录转移失败，脚本停止运行" >> $log
  echo "$(date '+%Y-%m-%d %H:%M:%S') - APP目录转移失败，脚本停止运行" 
  rm -rf $laotou_d >> $log
  am start com.android.settings/.Settings
  exit 1
fi
sleep 1

cp -a $sys_media $laotou_d >> $log
if [ $? -eq 0 ]; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') - MEDIA目录转移成功,开始转移DATA目录" >> $log
  echo "$(date '+%Y-%m-%d %H:%M:%S') - MEDIA目录转移成功,开始转移DATA目录"
else
  echo "$(date '+%Y-%m-%d %H:%M:%S') - MEDIA目录转移失败，脚本停止运行" >> $log
  echo "$(date '+%Y-%m-%d %H:%M:%S') - MEDIA目录转移失败，脚本停止运行"
  rm -rf $laotou_d >> $log
  am start com.android.settings/.Settings
  exit 1
fi
sleep 1

cp -a $sys_data $laotou_d >> $log
if [ $? -eq 0 ]; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') - DATA目录转移成功,数据目录迁移完成" >> $log
  echo "$(date '+%Y-%m-%d %H:%M:%S') - DATA目录转移成功,数据目录迁移完成"
else
  echo "$(date '+%Y-%m-%d %H:%M:%S') - DATA目录转移失败，脚本停止运行" >> $log
  echo "$(date '+%Y-%m-%d %H:%M:%S') - DATA目录转移失败，脚本停止运行"
  rm -rf $laotou_d >> $log
  am start com.android.settings/.Settings
  exit 1
fi

echo "$(date '+%Y-%m-%d %H:%M:%S') - 开始设置挂载脚本." >> $log
echo "$(date '+%Y-%m-%d %H:%M:%S') - 开始设置挂载脚本."
sleep 2
echo "=================================================="
cp -a $bin $bin_sys >> $log
if [ $? -eq 0 ]; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') - 1号脚本设置成功" >> $log
  echo "$(date '+%Y-%m-%d %H:%M:%S') - 1号脚本设置成功"
else
  echo "$(date '+%Y-%m-%d %H:%M:%S') - 1号脚本设置失败，脚本停止运行" >> $log
  echo "$(date '+%Y-%m-%d %H:%M:%S') - 1号脚本设置失败，脚本停止运行"
  am start com.android.settings/.Settings
  exit 1
fi

cp -a $laotou $laotou_sh >> $log
if [ $? -eq 0 ]; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') - 2号脚本设置成功" >> $log
  echo "$(date '+%Y-%m-%d %H:%M:%S') - 2号脚本设置成功" 
else
  echo "$(date '+%Y-%m-%d %H:%M:%S') - 2号脚本设置失败，脚本停止运行" >> $log
  echo "$(date '+%Y-%m-%d %H:%M:%S') - 2号脚本设置失败，脚本停止运行"
  am start com.android.settings/.Settings
  exit 1
fi

echo "=================================================="

grep "^service.adb.tcp.port=5555" /system/build.prop > /dev/null
if [ $? -eq 0 ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - ADB调试权限已经开启，无需再次操作！" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - ADB调试权限已经开启，无需再次操作！"
else
	echo service.adb.tcp.port=5555 >> /system/build.prop
    grep "^service.adb.tcp.port=5555" /system/build.prop > /dev/null
	if [ $? -eq 0 ]; then
		echo "$(date '+%Y-%m-%d %H:%M:%S') - ADB调试权限开启成功！" >> $log
		echo "$(date '+%Y-%m-%d %H:%M:%S') - ADB调试权限开启成功！" 
	else
		echo "$(date '+%Y-%m-%d %H:%M:%S') - ADB调试权限开启失败！" >> $log
		echo "$(date '+%Y-%m-%d %H:%M:%S') - ADB调试权限开启失败！"
	fi
fi
settings put global policy_control immersive.full=apps,-com.yftech.launcher,-com.yftech.settings,-com.baidu.iov.faceos,-com.baidu.xiaoduos.update,-com.baidu.iov.dueros.videoplayer,-com.baidu.bodyguard,-com.baidu.car.theme,-com.yftech.vehiclecenter,-com.baidu.naviauto
if [ $? -eq 0 ]; then
	echo "$(date '+%Y-%m-%d %H:%M:%S') - 界面优化成功！" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - 界面优化成功！"
else
	echo "$(date '+%Y-%m-%d %H:%M:%S') - 界面优化失败！" >> $log
	echo "$(date '+%Y-%m-%d %H:%M:%S') - 界面优化失败！"
fi

echo "=================================================="
echo " 	 *****         *     *"
echo " 	*     *        *   *"
echo " 	*     *        * *"
echo " 	*     *        **"
echo " 	*     *        * *"
echo " 	*     *        *   *"
echo "	 *****         *     *"
echo "==================================================" 
echo "==================================================" >> $log
echo "所有操作已结束，车机准备重启" >> $log
echo "所有操作已结束，车机准备重启"
sync
sleep 2
rm -rf $0 >> $log
reboot
